#include <stdio.h>

void main(){
	puts("DH{**flag**}\n");
}